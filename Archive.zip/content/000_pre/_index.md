+++
title = "Prerequisites"
chapter = true
weight = 1
+++

# Prerequisites for the Workshop

## What you need to get started!

If you are doing this workshop as part of an AWS event, you will be provided an AWS Account.

To login to that AWS Account, you will be given a unique **hash**, something as below:

*b76bbe879be74e988678bb4a831365f3*

To login - open a web browser,  navigate to https://dashboard.eventengine.run/ and enter the **hash** to proceed.

![fig0.1](images/fig0.1.png)

+++
title = "Run test with no-delete"
chapter = false
weight = 410
+++


## Execute the test. 

* Run **taskcat test run --no-delete** or **-n** flag to retain the CloudFormation stack 

```
taskcat test run --no-delete
```

### Launch the application after deployment.

* Once the taskcat test completes, navigate to the CloudFormation console by clicking...

$TODO
add link to CloudFormation console

**Complete the survey**
@TODO 
Add screenshort for the survey endpoint

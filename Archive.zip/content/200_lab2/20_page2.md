+++
title = "Execute a taskcat test"
chapter = false
weight = 220
+++



## Start a test

From the **cfn-project** dir run you taskcat test

```
taskcat test run
```

Expected output:
![fig1.1](/images/taskcat_execution.gif)

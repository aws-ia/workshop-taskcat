+++
title = "Add a (Project Level) config"
chapter = false
+++

### Project Config
Ths config file provides project specific configuration.

The project config file is located in the root of your project folder `<PROJECT_ROOT>/.taskcat.yml` 

From the vscode file browser navigate to **lab1/cfn-project**,  and open **.taskcat.yml** 

@TODO Screen shoot need updated to show appstream
![fig1.1](/images/fig_lab1.1.png)




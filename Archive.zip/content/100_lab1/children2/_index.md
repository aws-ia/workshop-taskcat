+++
title = "Execute a taskcat test"
chapter = true
+++



## Start a test

From the **lab-1/cfn-project** dir run you taskcat test

```
taskcat test run
```

Expected output:
![fig1.1](/images/taskcat_execution.gif)
